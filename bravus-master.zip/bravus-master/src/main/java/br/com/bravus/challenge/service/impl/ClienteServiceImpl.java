package br.com.bravus.challenge.service.impl;

import br.com.bravus.challenge.model.Cliente;
import br.com.bravus.challenge.repository.ClienteRepository;
import br.com.bravus.challenge.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class ClienteServiceImpl implements ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Override
    public Optional<Cliente> getCliente(String documento) {

        return clienteRepository.findByDocumento(documento);

    }
}
