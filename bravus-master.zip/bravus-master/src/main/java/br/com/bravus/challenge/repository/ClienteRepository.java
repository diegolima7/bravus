package br.com.bravus.challenge.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bravus.challenge.model.Cliente;

import java.util.Optional;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    Optional<Cliente> findByDocumento(String documento);

}
