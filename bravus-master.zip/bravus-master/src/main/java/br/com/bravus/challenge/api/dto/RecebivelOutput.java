package br.com.bravus.challenge.api.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecebivelOutput implements Serializable{
	private static final long serialVersionUID = -8692352673681095630L;
	private BigDecimal valor;
	private LocalDate dataVencimento;
	private Integer prazo;
	private String docCliente;
	private String nomeCliente;
	private BigDecimal valorImpostoCobrado;

}
