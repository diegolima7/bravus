package br.com.bravus.challenge.api.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.*;

@Getter
@Setter
public class RecebivelDTO {

	@NotNull(message = "Preencha o campo valor")
	private BigDecimal valor;
	
	@NotNull(message = "Preencha o campo Data Vencimento")
	private LocalDate dataVencimento;
	
	@NotBlank(message = "Preencha o campo Documento Cliente")
	private String documentoCliente;

	//OBS: seguir a especificação da tarefa, mas como farei uma busca do cliente na base
	// pelo numero do documento acredito que esse campo não seria necessário.
	@NotBlank(message = "Preencha o campo Nome Cliente")
	private String nomeCliente;

}
