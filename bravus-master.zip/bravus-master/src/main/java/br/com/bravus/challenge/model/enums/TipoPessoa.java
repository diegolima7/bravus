package br.com.bravus.challenge.model.enums;

public enum TipoPessoa {
	PJ(3.0),
	PF(1.5);
	double iof;
	TipoPessoa(double iof) {
		this.iof = iof;
	}
	public double getIOF() {
		return this.iof;
	}
}
