package br.com.bravus.challenge.api.controller;

import br.com.bravus.challenge.api.dto.RecebivelDTO;
import br.com.bravus.challenge.api.dto.RecebivelResponse;
import br.com.bravus.challenge.model.Recebivel;
import br.com.bravus.challenge.service.RecebivelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/recebiveis")
public class RecebivelController {

	@Autowired
	private RecebivelService recebivelService;

	@PostMapping(path = "/save")
	public ResponseEntity<HttpStatus> inserir(@Valid @RequestBody RecebivelDTO recebivelDTO) throws Exception {

		recebivelService.salvar(recebivelDTO);

		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@GetMapping(path = "/find")
	public ResponseEntity<RecebivelResponse> listar(){

		RecebivelResponse listaRecebivelResponse = recebivelService.listar();

		return new ResponseEntity<>(listaRecebivelResponse,HttpStatus.OK);
	}
	
}
