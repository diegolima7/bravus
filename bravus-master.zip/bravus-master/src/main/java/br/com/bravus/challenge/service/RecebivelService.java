package br.com.bravus.challenge.service;

import br.com.bravus.challenge.api.dto.RecebivelDTO;
import br.com.bravus.challenge.api.dto.RecebivelResponse;
import br.com.bravus.challenge.model.Recebivel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RecebivelService {
    void salvar(RecebivelDTO recebivelDTO) throws Exception;

    RecebivelResponse listar();

}
