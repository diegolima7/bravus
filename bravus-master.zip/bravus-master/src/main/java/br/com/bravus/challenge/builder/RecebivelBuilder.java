package br.com.bravus.challenge.builder;

import br.com.bravus.challenge.api.dto.RecebivelDTO;
import br.com.bravus.challenge.model.Cliente;
import br.com.bravus.challenge.model.Recebivel;
import lombok.Builder;

import java.math.BigDecimal;
@Builder
public class RecebivelBuilder {
    public Recebivel build(RecebivelDTO recebivelDTO, Cliente cliente, BigDecimal impostoIof, int prazo){

        Recebivel recebivelEntity = new Recebivel();

        recebivelEntity.setValor(recebivelDTO.getValor());
        recebivelEntity.setDataVencimento(recebivelDTO.getDataVencimento());
        recebivelEntity.setPrazo(prazo);
        recebivelEntity.setCliente(cliente);
        recebivelEntity.setValorTotalCalculado(impostoIof);

        return recebivelEntity;
    }
}
