package br.com.bravus.challenge.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bravus.challenge.model.Recebivel;

public interface RecebivelRepository extends JpaRepository<Recebivel, Long>{}
