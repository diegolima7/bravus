package br.com.bravus.challenge.service;

import br.com.bravus.challenge.model.Cliente;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface ClienteService {
    Optional<Cliente> getCliente(String documento);
}
