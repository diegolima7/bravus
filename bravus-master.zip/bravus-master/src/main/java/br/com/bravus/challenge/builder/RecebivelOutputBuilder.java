package br.com.bravus.challenge.builder;

import br.com.bravus.challenge.api.dto.RecebivelOutput;
import br.com.bravus.challenge.model.Recebivel;
import lombok.Builder;

@Builder
public class RecebivelOutputBuilder {
    public RecebivelOutput build(Recebivel recebivel){

        RecebivelOutput recebivelOutput = new RecebivelOutput();

        recebivelOutput.setValor(recebivel.getValor());
        recebivelOutput.setDataVencimento(recebivel.getDataVencimento());
        recebivelOutput.setPrazo(recebivel.getPrazo());
        recebivelOutput.setDocCliente(recebivel.getCliente().getDocumento());
        recebivelOutput.setNomeCliente(recebivel.getCliente().getNome());
        recebivelOutput.setValorImpostoCobrado(recebivel.getValorTotalCalculado());

        return recebivelOutput;
    }
}
