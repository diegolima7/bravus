package br.com.bravus.challenge.api.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MyFieldsErrors {
	
	private String nomeCampo;
	private String mensagem;
	
	public MyFieldsErrors(String nomeCampo, String mensagem) {
		super();
		this.nomeCampo = nomeCampo;
		this.mensagem = mensagem;
	}

	public MyFieldsErrors() {}
	
	
}
