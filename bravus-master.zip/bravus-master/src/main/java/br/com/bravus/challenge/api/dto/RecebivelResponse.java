package br.com.bravus.challenge.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
public class RecebivelResponse implements Serializable{
	List<List<RecebivelOutput>> recebivelListResponse;

}
