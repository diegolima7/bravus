package br.com.bravus.challenge.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "recebivel")
public class Recebivel implements Serializable{
	private static final long serialVersionUID = 2373621970032478717L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "valor")
	private BigDecimal valor;
	@Column(name = "data_vencimento")
	private LocalDate dataVencimento;
	@Column(name = "prazo")
	private Integer prazo;
	@ManyToOne
	private Cliente cliente;
	@Column(name = "valor_total_calculado")
	private BigDecimal valorTotalCalculado;

}
