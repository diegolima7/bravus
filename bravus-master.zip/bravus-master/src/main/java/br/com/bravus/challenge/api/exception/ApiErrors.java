package br.com.bravus.challenge.api.exception;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApiErrors {

    private HttpStatus status;
    private LocalDateTime dateTime;
    private List<MyFieldsErrors> myFieldsErrors = new ArrayList<>();
    
    public ApiErrors(HttpStatus status, LocalDateTime dateTime, MyFieldsErrors myFieldsError) {
        this.status = status;
        this.dateTime = dateTime;
        this.myFieldsErrors.add(myFieldsError);
    }

    public ApiErrors(HttpStatus status, LocalDateTime dateTime, List<MyFieldsErrors> myFieldsErrors) {
        this.status = status;
        this.dateTime = dateTime;
        this.myFieldsErrors= myFieldsErrors;
    }
}