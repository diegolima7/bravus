package br.com.bravus.challenge.service.impl;

import br.com.bravus.challenge.api.dto.RecebivelDTO;
import br.com.bravus.challenge.api.dto.RecebivelOutput;
import br.com.bravus.challenge.api.dto.RecebivelResponse;
import br.com.bravus.challenge.builder.RecebivelBuilder;
import br.com.bravus.challenge.builder.RecebivelOutputBuilder;
import br.com.bravus.challenge.model.Cliente;
import br.com.bravus.challenge.model.Recebivel;
import br.com.bravus.challenge.repository.RecebivelRepository;
import br.com.bravus.challenge.service.ClienteService;
import br.com.bravus.challenge.service.RecebivelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class RecebivelServiceImpl implements RecebivelService {

    @Autowired
    private RecebivelRepository recebivelRepository;

    @Autowired
    private RecebivelBuilder recebivelBuilder;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private RecebivelOutputBuilder recebivelOutputBuilder;

    private static final int qtdd_dias = 30;

    @Override
    public void salvar(RecebivelDTO recebivelDTO) throws Exception {

        Optional<Cliente> cliente = clienteService.getCliente(recebivelDTO.getDocumentoCliente());

        if (cliente.isPresent()){

            var prazo = calcularPrazoEmDias(recebivelDTO);

            BigDecimal valorImposto = calcularImposto(recebivelDTO, cliente, prazo);

            Recebivel recebivel = recebivelBuilder.build(recebivelDTO, cliente.get(), valorImposto, prazo);

            recebivelRepository.save(recebivel);

        }else{
            throw new Exception("Cliente não existe, favor cadastrar cliente.");
        }
    }

    private BigDecimal calcularImposto(RecebivelDTO recebivelDTO, Optional<Cliente> cliente, int prazo) {

        var taxaDiasIof = cliente.get().getTipoPessoa().getIOF() / qtdd_dias;

        var imposto = new BigDecimal((recebivelDTO.getValor().doubleValue() * taxaDiasIof) * prazo);

        return imposto;
    }

    private int calcularPrazoEmDias(RecebivelDTO recebivelDTO) {

        var prazoDias =  (int)ChronoUnit.DAYS.between(recebivelDTO.getDataVencimento(), LocalDate.now());

        return prazoDias;
    }
    @Override
    public RecebivelResponse listar(){

        List<Recebivel> recebivelRepositoryAll = recebivelRepository.findAll();

        List<RecebivelOutput> recebivelOutputList = Collections.emptyList();

        RecebivelResponse response = new RecebivelResponse();


        if(!recebivelRepositoryAll.isEmpty() || recebivelRepositoryAll == null){

            recebivelRepositoryAll.forEach(it -> {recebivelOutputList.add(recebivelOutputBuilder.build(it));});

            Map<String, List<RecebivelOutput>> recebivelOutputMap = recebivelOutputList.stream().collect(Collectors.groupingBy(RecebivelOutput::getDocCliente));

            recebivelOutputMap.forEach((k,v) -> response.setRecebivelListResponse(v));

        }
        return response;
    }


}
